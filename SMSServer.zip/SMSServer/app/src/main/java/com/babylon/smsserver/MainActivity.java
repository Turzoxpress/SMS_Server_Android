package com.babylon.smsserver;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MessageListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

       // MessageReceiver.bindListener(this);



       // sendSMS();
    }

    public void sendSMS(){

        SmsManager sms = SmsManager.getDefault();
        ArrayList<String> parts = sms.divideMessage("Testing SMS server");
        sms.sendMultipartTextMessage("+8801834261758", null, parts, null, null);
    }

    @Override
    public void messageReceived(String message) {
        Toast.makeText(this, "New Message Received: " + message, Toast.LENGTH_LONG).show();
        Log.e("MainActivity","New Message Received: " + message);
    }
}
